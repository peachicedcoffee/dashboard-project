﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace XDASCommunicationApp
{
    /// <summary>
    /// X-DAS 클라이언트 클래스
    /// </summary>
    public class XDASClient
    {
        private TcpClient tcpClient;
        private NetworkStream networkStream;
        private bool isConnected = false;
        private List<string> monitoringTags = new List<string>();

        public event EventHandler<string> ConnectionStatusChanged;
        public event EventHandler<XDASTagValue> DataReceived;
        public event EventHandler<string> ErrorOccurred;

        public bool IsConnected => isConnected && tcpClient?.Connected == true;
        public bool HasMonitoringTags => monitoringTags.Count > 0;

        /// <summary>
        /// 연결
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        /// <returns></returns>
        public async Task<bool> ConnectAsync(string ip, int port)
        {
            try
            {
                tcpClient = new TcpClient();
                await tcpClient.ConnectAsync(ip, port);
                networkStream = tcpClient.GetStream();

                isConnected = true;
                ConnectionStatusChanged?.Invoke(this, "연결됨");
                return true;
            }
            catch (Exception ex)
            {
                isConnected = false;
                ConnectionStatusChanged?.Invoke(this, "연결실패");
                ErrorOccurred?.Invoke(this, $"연결 실패: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// 연결해제
        /// </summary>
        public void Disconnect()
        {
            try
            {
                isConnected = false;
                monitoringTags.Clear();

                networkStream?.Close();
                tcpClient?.Close();

                ConnectionStatusChanged?.Invoke(this, "연결해제됨");
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, $"연결 해제 오류: {ex.Message}");
            }
        }

        /// <summary>
        /// 태그 읽기
        /// </summary>
        /// <param name="tagName"></param>
        /// <returns></returns>
        public async Task<XDASTagValue> ReadTagAsync(string tagName)
        {
            if (!IsConnected)
                throw new InvalidOperationException("X-DAS 서버에 연결되지 않았습니다.");

            try
            {
                // 실제 X-DAS 통신 프로토콜에 맞게 구현
                // 여기서는 시뮬레이션 데이터 반환
                await Task.Delay(100); // 통신 지연 시뮬레이션

                // 실제로는 X-DAS 프로토콜에 맞는 요청을 보내고 응답을 파싱해야 함
                return new XDASTagValue
                {
                    TagName = tagName,
                    Value = GenerateSimulatedValue(tagName),
                    Quality = "GOOD",
                    Timestamp = DateTime.Now
                };
            }
            catch (Exception ex)
            {
                return new XDASTagValue
                {
                    TagName = tagName,
                    Value = null,
                    Quality = "BAD",
                    Timestamp = DateTime.Now,
                    ErrorMessage = ex.Message
                };
            }
        }

        /// <summary>
        /// 태그 쓰기
        /// </summary>
        /// <param name="tagName"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public async Task<bool> WriteTagAsync(string tagName, object value)
        {
            if (!IsConnected)
                throw new InvalidOperationException("X-DAS 서버에 연결되지 않았습니다.");

            try
            {
                // 실제 X-DAS 통신 프로토콜에 맞게 구현
                await Task.Delay(100); // 통신 지연 시뮬레이션

                // 실제로는 X-DAS 프로토콜에 맞는 쓰기 명령을 보내야 함
                return true;
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, $"태그 '{tagName}' 쓰기 오류: {ex.Message}");
                return false;
            }
        }

        public void SetMonitoringTags(string[] tagNames)
        {
            monitoringTags.Clear();
            monitoringTags.AddRange(tagNames);
        }

        public void StopMonitoring()
        {
            monitoringTags.Clear();
        }

        public async Task RefreshMonitoringData()
        {
            if (!IsConnected || monitoringTags.Count == 0)
                return;

            try
            {
                foreach (string tagName in monitoringTags)
                {
                    var tagValue = await ReadTagAsync(tagName);
                    DataReceived?.Invoke(this, tagValue);
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, $"모니터링 데이터 갱신 오류: {ex.Message}");
            }
        }

        private object GenerateSimulatedValue(string tagName)
        {
            // 시뮬레이션을 위한 더미 데이터 생성
            var random = new Random();

            if (tagName.Contains("LEVEL"))
                return Math.Round(random.NextDouble() * 100, 2);
            else if (tagName.Contains("TEMP"))
                return Math.Round(random.NextDouble() * 50 + 20, 1);
            else if (tagName.Contains("STATUS"))
                return random.Next(0, 2) == 1 ? "ON" : "OFF";
            else if (tagName.Contains("PRESSURE"))
                return Math.Round(random.NextDouble() * 10 + 1, 2);
            else
                return Math.Round(random.NextDouble() * 1000, 2);
        }
    }
}
